def znajdz_somsiada(v, kraw, przyp):
    s = []
    for w1, w2 in kraw:
        if v == przyp[w1]:
            s.append(przyp[w2])
        elif v == przyp[w2]:
            s.append(przyp[w1])
    return s
nazwa_pliku = 'graf.txt'

with open(nazwa_pliku) as plik:
    krawedzie = plik.readlines()
    
k = [] #krawędzie
w = [] #wierzchołki
for i, kraw in enumerate(krawedzie):
    w1, w2 = kraw.split(' ')
    w2 = w2.rstrip()   
    k.append((w1, w2))
    if w1 not in w:
        w.append(w1)
    if w2 not in w:
        w.append(w2)
w.sort()
przypisanie = {}
for i, wierz in enumerate(w):
    przypisanie[wierz] = i


n = len(w)
S = []
C = [0 for i in range(n)]
cn = 0
for i in range(n):
    if C[i] > 0:
        continue
    cn += 1
    S.append(i)
    C[i] = cn
    while len(S)>0:
        v = S.pop(-1)
        somsiady = znajdz_somsiada(v, k, przypisanie)
        for u in somsiady:
            if C[u] >0:
                continue
            S.append(u)
            C[u] = cn

print('ilosc:', cn)
for i in range(1, cn+1):
    print('\ni: ', i)
    for j in range(n):
        if C[j] == i:
            print('j: ', end ='')
            for klucz, wartosc in przypisanie.items():
                if wartosc == j:
                    print(klucz)
