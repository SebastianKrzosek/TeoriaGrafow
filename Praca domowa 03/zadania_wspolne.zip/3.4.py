from Reprezentacja_grafu import Reprezentacja_grafu as rg
def BFS(L_incydencji, wierzcholek, w):
    L = [False for x in range(w)]; F = [-1 for x in range(w)]
    Q = [wierzcholek, ]
    L[wierzcholek] = True
    while len(Q) != 0:
        p = Q.pop(0)
        for u in L_incydencji[p]:
            if not L[u]:
                #print(u)
                Q.append(u)
                L[u] = True; F[u] = p
    return L, F

G = rg('digraf.txt', digraf = True)
L_i = G.listy_incydencji()
w = int(G.w)
l1, l2 = BFS(L_i, 0, w)
obecny = 4
p = [obecny,]
while obecny != 0:
    obecny = l2[obecny]
    p.append(obecny)
p.reverse()
print(p)

