import numpy as np
class Reprezentacja_grafu():
    '''Czyta dane z pliku (1 wiersz liczba wierzchołków, liczba krawędzi.        Reszta: numery wierzchołków tworzących krawędź)'''
    def __init__(self, nazwa_pliku, digraf=False):
        with open(nazwa_pliku) as plik:
            self.rozmiar = plik.readline()
            self.krawedzie = plik.readlines()
        self.w, self.k = self.rozmiar.split(' ')
        self.digraf = digraf
    def tablica_par(self):
        t_par = []
        if not self.digraf:
            for i, kraw in enumerate(self.krawedzie):
                w1, w2 = kraw.split(' ')
                w1 = int(w1); w2 = int(w2.rstrip())         
                if [w1, w2] not in t_par and [w2,w1] not in t_par:
                    t_par.append([w1, w2])
        else:
            for i, kraw in enumerate(self.krawedzie):
                w1, w2 = kraw.split(' ')
                w1 = int(w1); w2 = int(w2.rstrip())         
                if [w1, w2] not in t_par:
                    t_par.append([w1, w2])                
        return t_par    
    
    def listy_incydencji(self):
        l_incyd = [[] for x in range(int(self.w))]
        t_par = self.tablica_par()
        if not self.digraf:
            for w1, w2 in t_par:
                l_incyd[w1].append(w2)
                l_incyd[w2].append(w1)
        else:
            for w1, w2 in t_par:
                l_incyd[w1].append(w2)
        return l_incyd
    
    def dwie_listy(self):
        l_incyd = self.listy_incydencji()
        lista1 = []; lista2 = []
        ilosc = 0
        for el in l_incyd:
            lista1.append(ilosc); ilosc += len(el); lista2 = lista2 + el
        return lista1, lista2
    
    def macierz_sasiedztwa(self):
        mc = np.zeros((int(self.w),int(self.w)), dtype=int)
        t_par = self.tablica_par()
        if not self.digraf:
            for w1, w2 in t_par:
                mc[w1,w2] = 1; mc[w2,w1] = 1
        else: 
            for w1, w2 in t_par:
                mc[w1,w2] = 1
        return mc
    
    def macierz_incydencji(self):
        t_par = self.tablica_par()
        mc = np.zeros((int(self.w), len(t_par)), dtype=int)
        if not self.digraf:
            for i, (w1, w2) in enumerate(t_par):
                mc[w1,i] = 1
                mc[w2,i] = 1
        else:
            for i, (w1, w2) in enumerate(t_par):
                mc[w1,i] = -1
                mc[w2,i] = 1
        return mc
'''
print('Graf')
Graf1 = Reprezentacja_grafu('dane.txt')
print('Tablica par: ')
print(Graf1.tablica_par())
print('Listy incydencji: ')
print(Graf1.listy_incydencji())
print('Dwie listy: ')
print(Graf1.dwie_listy())
print('Macierz sąsiedztwa: ')
print(Graf1.macierz_sasiedztwa())
print('Macierz incydencji: ')
print(Graf1.macierz_incydencji())



print('\n\n\nDiraf')
Graf2 = Reprezentacja_grafu('dane2.txt', digraf = True)
print('Tablica par: ')
print(Graf2.tablica_par())
print('Listy incydencji: ')
print(Graf2.listy_incydencji())
print('Dwie listy: ')
print(Graf2.dwie_listy())
print('Macierz sąsiedztwa: ')
print(Graf2.macierz_sasiedztwa())
print('Macierz incydencji: ')
print(Graf2.macierz_incydencji())'''
